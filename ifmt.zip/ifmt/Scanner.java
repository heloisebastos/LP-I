package ifmt;

public interface Scanner {
	
	public void copiar();

}
