package ifmt;

public class ImpressoraLaser implements Impressora {

	@Override
	public void imprimir() {

		System.out.println("Impress�o a laser");
	}

}
