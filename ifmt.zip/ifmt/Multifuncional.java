package ifmt;

public class Multifuncional implements Impressora, Scanner {

	@Override
	public void copiar() {
		System.out.println("Copiar Multi");
	}

	@Override
	public void imprimir() {
		System.out.println("Imprimir Multi");
		
	}

}
