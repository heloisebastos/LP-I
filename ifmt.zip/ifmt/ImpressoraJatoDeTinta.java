package ifmt;

public class ImpressoraJatoDeTinta implements Impressora {

	@Override
	public void imprimir() {

			System.out.println("Impress�o Jato Tinta");
	}

	
}
