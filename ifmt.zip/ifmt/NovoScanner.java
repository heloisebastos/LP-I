package ifmt;

public class NovoScanner implements Scanner {

	@Override
	public void copiar() {
		System.out.println("Copiar");
	}

}
