package ifmt;

public interface Impressora {

	public void imprimir();
}
