package ifmt;

public class Teste {

	
	public static void main(String[] args) {
		
		ImpressoraJatoDeTinta ijdt = new ImpressoraJatoDeTinta();
		ImpressoraLaser il = new ImpressoraLaser();
		Multifuncional mf = new Multifuncional();
		realizarImpressao(mf);
		
		NovoScanner scan = new NovoScanner();
		criarCopia(mf);
	}
	
	
	public static void realizarImpressao(Impressora i) {
		
		i.imprimir();
	}
	
	public static void criarCopia(Scanner scan) {
		scan.copiar();
	}
}
