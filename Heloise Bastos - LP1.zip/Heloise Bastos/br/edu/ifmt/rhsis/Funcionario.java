package br.edu.ifmt.rhsis;

public class Funcionario {
	private String nome1;
	private String matricula;
	private double salario;
	private int tipo;
	
	public Funcionario(String nome1,String matricula,int tipo,double salario){
		this.nome1=nome1;
		this.matricula=matricula;
		this.tipo=tipo;
		this.salario=salario;
		
	}

	public String getNome1() {
		return nome1;
	}

	public void setNome1(String nome1) {
		this.nome1 = nome1;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return "Funcionario [nome1=" + nome1 + ", matricula=" + matricula + ", salario=" + salario + ", tipo=" + tipo+ "]";
	}

	
	
}
